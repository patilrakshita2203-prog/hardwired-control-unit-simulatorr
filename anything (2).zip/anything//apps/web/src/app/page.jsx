"use client";

import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  RotateCcw,
  Cpu,
  Database,
  Activity,
  Terminal,
  Settings,
  Info,
  ChevronRight,
  AlertCircle,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Toaster, toast } from "sonner";

// --- Constants & Types ---
const PHASES = ["FETCH", "DECODE", "EXECUTE", "MEMORY", "WRITEBACK"];
const INSTRUCTIONS = [
  {
    id: "ADD",
    label: "ADD R3, R1, R2",
    description: "Add R1 and R2, store in R3",
  },
  {
    id: "SUB",
    label: "SUB R3, R1, R2",
    description: "Subtract R2 from R1, store in R3",
  },
  {
    id: "LOAD",
    label: "LOAD R1, [Addr]",
    description: "Load value from Memory Address to R1",
  },
  {
    id: "STORE",
    label: "STORE R1, [Addr]",
    description: "Store value from R1 to Memory Address",
  },
];

export default function ControlUnitSimulator() {
  // --- State ---
  const [registers, setRegisters] = useState({ R1: 10, R2: 20, R3: 0 });
  const [memory, setMemory] = useState(
    Array(8)
      .fill(0)
      .map((_, i) => ({ addr: i, val: i * 5 })),
  );
  const [selectedInst, setSelectedInst] = useState("ADD");
  const [targetAddr, setTargetAddr] = useState(0);
  const [phaseIndex, setPhaseIndex] = useState(-1); // -1 means idle
  const [logs, setLogs] = useState([]);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [speed, setSpeed] = useState(1000);
  const [pc, setPc] = useState(0); // PC starts at 0
  const [error, setError] = useState(null);

  const timerRef = useRef(null);
  const logEndRef = useRef(null);

  // --- Derived State (Control Signals) ---
  const controlSignals = useMemo(() => {
    if (phaseIndex === -1)
      return {
        RegWrite: 0,
        ALUSrc: 0,
        MemRead: 0,
        MemWrite: 0,
        PCWrite: 0,
        MemToReg: 0,
      };

    const phase = PHASES[phaseIndex];
    const inst = selectedInst;

    const signals = {
      RegWrite: 0,
      ALUSrc: 0,
      MemRead: 0,
      MemWrite: 0,
      PCWrite: 0,
      MemToReg: 0,
    };

    if (phase === "FETCH") {
      signals.PCWrite = 1;
    } else if (phase === "DECODE") {
      // Decode phase doesn't typically assert these execution signals yet
    } else if (phase === "EXECUTE") {
      if (inst === "ADD" || inst === "SUB") {
        signals.ALUSrc = 0; // Register input
      } else if (inst === "LOAD" || inst === "STORE") {
        signals.ALUSrc = 1; // Address/Offset input
      }
    } else if (phase === "MEMORY") {
      if (inst === "LOAD") signals.MemRead = 1;
      if (inst === "STORE") signals.MemWrite = 1;
    } else if (phase === "WRITEBACK") {
      if (inst === "ADD" || inst === "SUB" || inst === "LOAD") {
        signals.RegWrite = 1;
        signals.MemToReg = inst === "LOAD" ? 1 : 0;
      }
    }

    return signals;
  }, [phaseIndex, selectedInst]);

  // --- Helpers ---
  const addLog = (msg) => {
    setLogs((prev) => [
      ...prev,
      { time: new Date().toLocaleTimeString(), msg },
    ]);
  };

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  // --- Simulation Logic ---
  const nextStep = () => {
    setError(null);
    const nextIndex = phaseIndex + 1;

    if (nextIndex >= PHASES.length) {
      addLog("Instruction cycle complete.");
      setPhaseIndex(-1);
      setIsAutoPlaying(false);
      return;
    }

    const currentPhase = PHASES[nextIndex];

    // Logic Execution per phase
    try {
      if (currentPhase === "FETCH") {
        addLog(`Fetching instruction: ${selectedInst} at PC: ${pc}`);
        setPc((prev) => prev + 1);
      } else if (currentPhase === "DECODE") {
        addLog(`Decoding ${selectedInst}. Opcode recognized.`);
      } else if (currentPhase === "EXECUTE") {
        addLog(`Executing ${selectedInst} operation in ALU.`);
        if (selectedInst === "ADD") {
          // Internal simulation of ALU
        }
      } else if (currentPhase === "MEMORY") {
        if (selectedInst === "LOAD" || selectedInst === "STORE") {
          addLog(
            `${selectedInst === "LOAD" ? "Reading from" : "Writing to"} memory address ${targetAddr}.`,
          );
        } else {
          addLog("No memory access required for this instruction.");
        }
      } else if (currentPhase === "WRITEBACK") {
        addLog(`Writing back results to registers.`);
        // Actually perform the state update at the end of cycle
        if (selectedInst === "ADD") {
          setRegisters((prev) => ({ ...prev, R3: prev.R1 + prev.R2 }));
          toast.success(`R3 updated: ${registers.R1 + registers.R2}`);
        } else if (selectedInst === "SUB") {
          setRegisters((prev) => ({ ...prev, R3: prev.R1 - prev.R2 }));
          toast.success(`R3 updated: ${registers.R1 - registers.R2}`);
        } else if (selectedInst === "LOAD") {
          const val = memory.find((m) => m.addr === targetAddr)?.val || 0;
          setRegisters((prev) => ({ ...prev, R1: val }));
          toast.success(`R1 updated from Memory[${targetAddr}]: ${val}`);
        } else if (selectedInst === "STORE") {
          setMemory((prev) =>
            prev.map((m) =>
              m.addr === targetAddr ? { ...m, val: registers.R1 } : m,
            ),
          );
          toast.success(`Memory[${targetAddr}] updated: ${registers.R1}`);
        }
      }
    } catch (e) {
      setError(`Execution halted: Path conflict detected in ${currentPhase}`);
      setIsAutoPlaying(false);
      return;
    }

    setPhaseIndex(nextIndex);
  };

  const resetSim = () => {
    setPhaseIndex(-1);
    setPc(0); // Reset PC to 0
    setLogs([
      { time: new Date().toLocaleTimeString(), msg: "Simulator Reset." },
    ]);
    setIsAutoPlaying(false);
    setError(null);
  };

  // --- Auto Play Effect ---
  useEffect(() => {
    if (isAutoPlaying) {
      timerRef.current = setInterval(() => {
        nextStep();
      }, speed);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [isAutoPlaying, phaseIndex, speed, selectedInst]);

  // Get next phase for button label
  const getNextPhase = () => {
    const nextIndex = phaseIndex + 1;
    if (nextIndex >= PHASES.length) {
      return "FETCH";
    }
    return PHASES[nextIndex];
  };

  // --- Component Rendering ---
  const isActive = (phase) => phaseIndex !== -1 && PHASES[phaseIndex] === phase;

  const Block = ({ name, active, icon: Icon, children, className }) => (
    <motion.div
      animate={{
        scale: active ? 1.05 : 1,
        borderColor: active ? "#3b82f6" : "#334155",
        boxShadow: active ? "0 0 20px rgba(59, 130, 246, 0.4)" : "none",
      }}
      className={`relative bg-slate-900 border-2 rounded-xl p-4 flex flex-col items-center justify-center gap-2 min-w-[120px] transition-all z-10 ${className}`}
    >
      <div
        className={`p-2 rounded-lg ${active ? "bg-blue-500/20 text-blue-400" : "bg-slate-800 text-slate-400"}`}
      >
        <Icon size={20} />
      </div>
      <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
        {name}
      </span>
      {children}
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-[#0a0f18] text-slate-200 font-sans p-6 overflow-hidden">
      <Toaster position="top-right" theme="dark" />

      {/* Header */}
      <div className="flex items-center justify-between mb-8 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-500/20">
            <Cpu size={32} className="text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Interactive Hardwired Control Unit Simulator
            </h1>
            <p className="text-sm text-slate-400 font-medium">
              ADLD Lab Project - Educational CPU Pipeline
            </p>
          </div>
        </div>

        {/* Simplified Control Buttons - Conditional rendering based on state */}
        <div className="flex items-center gap-3">
          <button
            onClick={resetSim}
            className="flex items-center gap-2 px-5 py-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-300 transition-all active:scale-95 border border-slate-700"
            title="Reset Simulator"
          >
            <RotateCcw size={20} />
            <span className="font-semibold">Reset</span>
          </button>

          {phaseIndex === -1 ? (
            // Show "Start Instruction" button when idle
            <button
              onClick={nextStep}
              className="flex items-center gap-3 px-12 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xl transition-all active:scale-95 shadow-lg shadow-blue-600/30"
            >
              <span>Start Instruction</span>
              <ChevronRight size={28} />
            </button>
          ) : (
            // Show "Next Step" button when running
            <button
              onClick={nextStep}
              className="flex items-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-lg transition-all active:scale-95 shadow-lg shadow-blue-600/20"
            >
              <span>Next Step: {getNextPhase()}</span>
              <ChevronRight size={24} />
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 h-[calc(100vh-160px)]">
        {/* Left Sidebar: Inputs */}
        <div className="col-span-3 space-y-6 overflow-y-auto pr-2 custom-scrollbar">
          <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-5">
            <h2 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
              <Settings size={16} /> INSTRUCTION SETUP
            </h2>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-500 mb-2 block uppercase">
                  Select Instruction
                </label>
                <select
                  value={selectedInst}
                  onChange={(e) => {
                    setSelectedInst(e.target.value);
                    resetSim();
                  }}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  {INSTRUCTIONS.map((inst) => (
                    <option key={inst.id} value={inst.id}>
                      {inst.label}
                    </option>
                  ))}
                </select>
                <p className="mt-2 text-[10px] text-slate-500 leading-relaxed italic">
                  {INSTRUCTIONS.find((i) => i.id === selectedInst).description}
                </p>
              </div>

              {(selectedInst === "LOAD" || selectedInst === "STORE") && (
                <div>
                  <label className="text-xs font-bold text-slate-500 mb-2 block uppercase">
                    Target Address (0-7)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="7"
                    value={targetAddr}
                    onChange={(e) => setTargetAddr(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-5">
            <h2 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
              <Database size={16} /> REGISTER FILE
            </h2>
            <div className="grid grid-cols-1 gap-3">
              {Object.entries(registers).map(([reg, val]) => (
                <div
                  key={reg}
                  className="bg-slate-950/50 border border-slate-800 rounded-xl p-3 flex items-center justify-between group transition-all hover:border-slate-700"
                >
                  <span className="font-mono text-blue-400 font-bold">
                    {reg}
                  </span>
                  <input
                    type="number"
                    value={val}
                    onChange={(e) =>
                      setRegisters((prev) => ({
                        ...prev,
                        [reg]: Number(e.target.value),
                      }))
                    }
                    className="bg-transparent text-right w-20 font-mono text-slate-100 outline-none"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-5">
            <h2 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
              <Info size={16} /> DATA MEMORY
            </h2>
            <div className="grid grid-cols-2 gap-2">
              {memory.map((m) => (
                <div
                  key={m.addr}
                  className="bg-slate-950/50 border border-slate-800 rounded-xl p-2 flex flex-col items-center"
                >
                  <span className="text-[10px] font-bold text-slate-600 mb-1">
                    0x0{m.addr}
                  </span>
                  <input
                    type="number"
                    value={m.val}
                    onChange={(e) =>
                      setMemory((prev) =>
                        prev.map((x) =>
                          x.addr === m.addr
                            ? { ...x, val: Number(e.target.value) }
                            : x,
                        ),
                      )
                    }
                    className="bg-transparent text-center w-full font-mono text-sm text-slate-300 outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Center: Datapath Visualization */}
        <div className="col-span-6 relative bg-slate-950/50 border border-slate-800 rounded-3xl overflow-hidden p-8 shadow-inner">
          {/* Phase Overlay */}
          <div className="absolute top-6 left-1/2 -translate-x-1/2 z-10">
            <div className="flex gap-2 p-1.5 bg-slate-900 border border-slate-800 rounded-full shadow-2xl">
              {PHASES.map((p, i) => (
                <div
                  key={p}
                  className={`px-4 py-1.5 rounded-full text-[10px] font-black transition-all ${
                    phaseIndex === i
                      ? "bg-blue-600 text-white scale-110"
                      : phaseIndex > i
                        ? "bg-slate-800 text-slate-500"
                        : "text-slate-600"
                  }`}
                >
                  {p}
                </div>
              ))}
            </div>
          </div>

          {/* SVG Connections (Wires) - Completely direct, no intermediate dots */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            <defs>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* PC -> IM (Direct horizontal) */}
            <line
              x1="180"
              y1="180"
              x2="250"
              y2="180"
              stroke={isActive("FETCH") ? "#3b82f6" : "#1e293b"}
              strokeWidth={isActive("FETCH") ? 4 : 2}
              filter={isActive("FETCH") ? "url(#glow)" : ""}
              className="transition-all duration-500"
            />

            {/* IM -> CU (Direct horizontal) */}
            <line
              x1="380"
              y1="180"
              x2="450"
              y2="180"
              stroke={isActive("DECODE") ? "#3b82f6" : "#1e293b"}
              strokeWidth={isActive("DECODE") ? 4 : 2}
              filter={isActive("DECODE") ? "url(#glow)" : ""}
              className="transition-all duration-500"
            />

            {/* Regs -> ALU (Direct horizontal) */}
            <line
              x1="380"
              y1="400"
              x2="480"
              y2="400"
              stroke={isActive("EXECUTE") ? "#3b82f6" : "#1e293b"}
              strokeWidth={isActive("EXECUTE") ? 4 : 2}
              filter={isActive("EXECUTE") ? "url(#glow)" : ""}
              className="transition-all duration-500"
            />

            {/* ALU -> Data Memory (Direct horizontal) */}
            <line
              x1="580"
              y1="400"
              x2="650"
              y2="400"
              stroke={isActive("MEMORY") ? "#3b82f6" : "#1e293b"}
              strokeWidth={isActive("MEMORY") ? 4 : 2}
              filter={isActive("MEMORY") ? "url(#glow)" : ""}
              className="transition-all duration-500"
            />

            {/* Writeback: Data Memory -> Registers (Direct vertical down, then back up) */}
            <polyline
              points="720,440 720,480 320,480 320,440"
              fill="none"
              stroke={isActive("WRITEBACK") ? "#3b82f6" : "#1e293b"}
              strokeWidth={isActive("WRITEBACK") ? 4 : 2}
              filter={isActive("WRITEBACK") ? "url(#glow)" : ""}
              className="transition-all duration-500"
            />
          </svg>

          {/* Datapath Blocks Grid - Removed intermediate placeholders */}
          <div className="relative z-10 w-full h-full grid grid-cols-3 grid-rows-3 gap-12 p-12">
            <div className="flex items-center justify-center">
              <Block name="PC" active={isActive("FETCH")} icon={Activity}>
                <span className="font-mono text-xl text-white">{pc}</span>
              </Block>
            </div>
            <div className="flex items-center justify-center">
              <Block
                name="Instr Memory"
                active={isActive("FETCH") || isActive("DECODE")}
                icon={Database}
              >
                <span className="text-[10px] text-blue-400 font-bold">
                  {selectedInst}
                </span>
              </Block>
            </div>
            <div className="invisible" />

            <div className="flex items-center justify-center">
              <Block
                name="Control Unit"
                active={phaseIndex !== -1}
                icon={Cpu}
                className="h-44"
              >
                <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 mt-2">
                  {Object.entries(controlSignals).map(([sig, val]) => (
                    <div
                      key={sig}
                      className="flex items-center justify-between gap-3"
                    >
                      <span className="text-[8px] text-slate-500 font-black tracking-tighter">
                        {sig}
                      </span>
                      <div
                        className={`w-2 h-2 rounded-full ${val ? "bg-emerald-500 shadow-[0_0_8px_#10b981]" : "bg-slate-800"}`}
                      />
                    </div>
                  ))}
                </div>
              </Block>
            </div>
            <div className="flex items-center justify-center">
              <Block
                name="Registers"
                active={isActive("DECODE") || isActive("WRITEBACK")}
                icon={Database}
                className="w-48"
              >
                <div className="w-full space-y-1.5">
                  {Object.entries(registers).map(([r, v]) => (
                    <div
                      key={r}
                      className="flex justify-between text-[11px] border-b border-slate-800/50 pb-0.5"
                    >
                      <span className="text-slate-500 font-bold">{r}</span>
                      <span className="text-white font-mono">{v}</span>
                    </div>
                  ))}
                </div>
              </Block>
            </div>
            <div className="flex items-center justify-center">
              <Block name="ALU" active={isActive("EXECUTE")} icon={Activity}>
                <div className="flex flex-col items-center py-1">
                  <span className="text-[10px] text-slate-400 font-black mb-1">
                    {selectedInst === "SUB" ? "SUB" : "ADD"}
                  </span>
                  <ChevronRight size={20} className="text-blue-500 rotate-90" />
                </div>
              </Block>
            </div>

            <div className="invisible" />
            <div className="invisible" />
            <div className="flex items-center justify-center">
              <Block
                name="Data Memory"
                active={isActive("MEMORY")}
                icon={Database}
              >
                <div className="px-2 py-1 bg-slate-950 rounded text-[9px] font-bold text-slate-500">
                  {selectedInst === "LOAD"
                    ? "READ"
                    : selectedInst === "STORE"
                      ? "WRITE"
                      : "IDLE"}
                </div>
              </Block>
            </div>
          </div>

          {/* Error Alert */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="absolute bottom-6 left-6 right-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400 z-50 backdrop-blur-md"
              >
                <AlertCircle size={20} />
                <span className="text-sm font-bold">{error}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Sidebar: Logs & Output */}
        <div className="col-span-3 flex flex-col gap-6">
          <div className="flex-1 bg-slate-900/50 rounded-2xl border border-slate-800 p-5 flex flex-col">
            <h2 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2">
              <Terminal size={16} /> SIMULATION LOG
            </h2>
            <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
              {logs.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-slate-600">
                  <Terminal size={40} className="mb-2 opacity-20" />
                  <p className="text-xs font-bold italic">
                    Waiting for instruction...
                  </p>
                </div>
              )}
              {logs.map((log, i) => (
                <div
                  key={i}
                  className="text-[11px] leading-relaxed animate-in fade-in slide-in-from-right-1"
                >
                  <span className="text-slate-600 font-mono">[{log.time}]</span>{" "}
                  <span className="text-slate-300">{log.msg}</span>
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          </div>

          <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-5">
            <h2 className="text-sm font-bold text-slate-400 mb-4">
              FINAL OUTPUT
            </h2>
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-bold text-slate-500">
                    ACCUMULATOR / R3
                  </span>
                  <span className="text-xs font-mono text-emerald-400 font-bold">
                    {registers.R3}
                  </span>
                </div>
                <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500"
                    style={{ width: "100%" }}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col items-center">
                  <span className="text-[10px] font-bold text-slate-500 mb-1">
                    MEM READS
                  </span>
                  <span className="text-xl font-bold text-white">
                    {logs.filter((l) => l.msg.includes("Reading")).length}
                  </span>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col items-center">
                  <span className="text-[10px] font-bold text-slate-500 mb-1">
                    MEM WRITES
                  </span>
                  <span className="text-xl font-bold text-white">
                    {logs.filter((l) => l.msg.includes("Writing")).length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');
        
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #334155;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #475569;
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
      `}</style>
    </div>
  );
}
